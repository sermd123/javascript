function  makeChair( n ){
  return `<td onclick="book( ${n});" >
  <img src="images/chair.png" alt="" />
  <h3>${n}</h3>
  </td>`;
}



function makeRow(count) {
  var row = "";
  for (var i = 1; i <= count; i++){
    console.log( makeChair( i ));
    row+= makeChair( i );
      }
      // alert(row);
      return row;
}

document.getElementById( 'row' ).innerHTML = makeRow ( 9) ;


function book( n ){
  confirm(`BOOK This seat ${n} ` );
}




// makeRow(3);
