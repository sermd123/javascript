function loadContent(){
    var xhr = new XMLHttpRequest();
    // 1) request > HERO.HTML
    xhr.open("GET","hero.html");

    xhr.onload = function(){
    console.log(xhr.responseText);
    document.getElementById('container').innerHTML = xhr.responseText;
    }
    // 2) RESPONCE <=
    xhr.send();

    // 3) RESPONCE => HERO.HTML
    
   
}