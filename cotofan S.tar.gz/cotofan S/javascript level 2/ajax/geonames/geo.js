const USERNAME = 'vaneatka';
const URL_COUNTRIES = 'http://api.geonames.org/countryInfoJSON'
const URL_CITIES = 'http://api.geonames.org/searchJSON'
function loadCountries (){

  var findCountry = document.getElementsByClassName('countries')[0];

  var xhr = new XMLHttpRequest();
      xhr.open("GET" , URL_COUNTRIES + '?username=' + USERNAME);
      xhr.onload = function (){
     var data = JSON.parse (xhr.responseText);
     //console.log (data.geonames[0]);
     for (var i=0; i<data.geonames.length; i++ ){
     var country = data.geonames[i];
    console.log(country);
    findCountry.innerHTML += '<option value ='+ country.countryCode + '>' + country.countryName + '</option>';
  }
}


  xhr.send()
}
loadCountries();




function loadCities (){

  var findCountry = document.getElementsByClassName('countries')[0];
  var findCity = document.getElementsByClassName('cities')[0];

  var xhr = new XMLHttpRequest();
      xhr.open("GET" , URL_CITIES + '?username=' + USERNAME + '&country=' + findCountry.value );
      xhr.onload = function (){
     var data = JSON.parse (xhr.responseText);
     //console.log (data.geonames[0]);
     for (var i=0; i<data.geonames.length; i++ ){
     var city = data.geonames[i];
    console.log(countryCode);
    console.log(countryName);
    findCity.innerHTML += '<option value ='+ city.countryName + '>' + city.ToponyName + '</option>';
  }
}


  xhr.send()
}
loadCountries();
