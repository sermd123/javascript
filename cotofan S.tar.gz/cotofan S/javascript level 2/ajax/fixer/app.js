const KEY = 'eaf123a33a563c14a7c5196f5e4f2d8d' // это ключ доступа 
const URL = 'http://data.fixer.io/api/latest'  // точка доступа куда мы обращяемся
var data = null;

function load(){

var xhr = new XMLHttpRequest();


xhr.onload = function(){
    console.log(xhr.responseText);
    data = JSON.parse(xhr.responseText);
    // console.log(data.rates.USD);
    updateList();
}
xhr.open("GET",URL+'?access_key='+KEY);

xhr.send();
}

function updateList(){
 var select = document.getElementById('currency');
 select.innerHTML +='<option value ="USD"> USD'+data.rates.USD + '</option>';
 select.innerHTML +='<option value ="MDL"> MDL'+data.rates.MDL + '</option>';
 select.innerHTML +='<option value ="RUB"> RUB'+data.rates.RUB + '</option>';
}

function convert(){
var amount = +document.getElementById('amount').value;
var currency_code = document.getElementById('currency').value;
var k = data.rates[currency_code]; 
console.log(amount,k)

var result = document.getElementById('result');
 result.value = (amount/k).toFixed(2);


}
