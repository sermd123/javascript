function processAddressFrom(){
var input_from = document.getElementById('input-address-from');
var address_from = input_from.value;
if (address_from.length<3) return;  // exit function

////////////////////////////////////////////////////////////////
localStorage.setItem('address_from', address_from);
console.log(address_from);
}

function restoreAddressFrom(){
    var input_from = document.getElementById('input-address-from');
    var address_from = localStorage.getItem('address_from');
    if (address_from != null) {
      input_from.value = address_from;

    }
}
// domaska sdelati vtoroe pole takje kak i pervoe
// при нажитии на батн сделать что бы поменялись значения в полях и в локал стораже

//

function clearAddressFrom(){
    var input_from = document.getElementById('input-address-from');
    input_from.value = "";
    localStorage.removeItem('address_from');
}
