/*// ogorod - 10 u4astkov//*/

var garden = ['pepper',  //0
              'piper2',  //1
              'corn',    //2
              'corn',    //3
              'Pumpkin', //4
              '',        //5
              '',        //6
              '',        //7
              '',        //8
              ''         //9
            ];


            function showParcel (i){
             var div = document.getElementById('garden');
             if (garden[i] == 'pepper' ) {

                 div.innerHTML += "<div><img src='images/piper.png'/></div>" ;   //eto mi obratilisi k pepemennoi div
            }
            if (garden[i] == 'corn' ) {

                div.innerHTML += "<div><img src='images/corn.png'/></div>" ;   //eto mi obratilisi k pepemennoi div
           }
           if (garden[i] == 'Pumpkin' ) {

                div.innerHTML += "<div><img src='images/Pumpkin.png'/></div>" ;
           }
           if (garden[i] == 'piper2' ) {

                div.innerHTML += "<div><img src='images/piper2.png'/></div>" ;
           }
           if (garden[i] == '' ) {

                div.innerHTML += "<div></div>" ;
           }
            }


              //eto nomer ea4eiki
// //////////////////////////////////////////////////////


 for (var i = 0; i <10; i++) {

showParcel(i);
}


// showParcel(0);
// showParcel(1);
// showParcel(2);
// showParcel(3);
// showParcel(4);
// showParcel(5);
