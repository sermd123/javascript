function sendMessage(){
  // 1 find input
  var input = document.querySelector('.messages-form input  ');
  console.log(input);
  // 2 read value

  var text = input.value;
  console.log(text);

  // 3 find DIV.messages
  var div = document.querySelector('.messages');
  console.log(div);
  // 3.a obrabotka messages

  text = text.replace(":)","<img src='images/1.png'>");
  text = text.replace("=)","<img src='images/2.png'>");
  text = text.replace("))","<img src='images/3.png'>");

  // 4 add text to div



  div.innerHTML += "<p>" + text + "</p>";
 // 5 delete text from input

 input.value = "";

}

// setTimeout (f(), period)
// setInterval (f(), period)
// clearTimeOut (id)
// clearInterval (id)



function typing(){

  // 1 find DIV
  var div = document.querySelector('.typing');

  // 2 put image
  div.innerHTML = "<img src='images/q.gif'>";

  // remove animation  after 3 seconds
  setTimeout ( stoppedTyping, 3000);

  }

function stoppedTyping(){
  // 1 find DIV
  var div = document.querySelector('.typing');
  // 2 delete image
  div.innerHTML = "";
}
