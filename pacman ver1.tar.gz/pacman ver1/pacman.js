// legend
// 0 -empty
// 1 - banan - 1
// 3 - banan -3
// 4 - bomb  - 4
// 5 - STENKA - Walls
// 6 minion -
// 9 pacman
var pac_r = 4;
var pac_c = 4;


var map = [
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 3, 0, 0, 0, 0, 1, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 9, 4, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 4, 0, 0, 4, 0, 0, 0, 0],
    [0, 0, 0, 6, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
];




function randBombs(amount) {
    amount = amount || 5; // initialization of |   or ||
    while (amount--) { // переписать этот фрагмент кода под цикл FOR
        var r_r = randCoord();
        var r_c = randCoord();
        map[r_r][r_c] = 4;
    }
}

function randWalls(amount) {
    amount = amount || 5; // initialization of |   or ||
    while (amount--) { // переписать этот фрагмент кода под цикл FOR

        var r_r = randCoord();
        var r_c = randCoord();
        var dir = Math.random()>0.5?'vertical': 'horizontal';
        for (var l = 0; l< randCoord()/2; l ++ ){
            if (dir == 'vertical'){
                if (r_r+l >9) break;
                map[r_r+l][r_c] = 5;
            }
            else {
                if(r_c+l>9)break;
                map[r_r][r_c+l] = 5;
            }

    }}
}
// сделать чтобы  также  с бананами
randWalls(3);

function randCoord() {
    return Math.ceil(Math.random() * 9) // ceil ///// это свойство которое приводит к целому числу .... RANDOM генерирует случайное число
}


function action() {
    console.log(event.keyCode);
    switch (event.keyCode) {
        case 37:
            moveLeft();
            break;
        case 38:
            moveUp();
            break;
        case 39:
            moveRight();
            break;
        case 40:
            moveDown();
            break;



    }
}


function checkBomb() {
    if (map[pac_r][pac_c] == 4) {
        map[pac_r][pac_c] = 10;
    } else {
        map[pac_r][pac_c] = 9;
    }
}

function moveRight() {
    if (pac_c < 9&&map[pac_r][pac_c+1]!=5) {
        map[pac_r][pac_c] = 0; // delete from current location
        pac_c++;
        checkBomb();
    }

    showMap();
}



function moveLeft() {
    if (pac_c > 0&&map[pac_r][pac_c-1]!=5) {
        map[pac_r][pac_c] = 0; // delete from current location
        pac_c--;
        checkBomb();
    } // show in new coordinates
    showMap();

}

function moveDown() {
    if (pac_r < 9&&map[pac_r+1][pac_c]!=5) {
        map[pac_r][pac_c] = 0; // delete from current location
        pac_r++;
        checkBomb();
    } // show in new coordinates
    showMap();
}

function moveUp() {
    if (pac_r > 0&&map[pac_r-1][pac_c]!=5) {
        map[pac_r][pac_c] = 0; // delete from current location
        pac_r--;
        checkBomb()
    } // show in new coordinates
    showMap();

}


function showMap() {
    var div_map = document.querySelector('#map');
    div_map.innerHTML = "";
    for (var r = 0; r < 10; r++) {
        for (var c = 0; c < 10; c++) {
            if (map[r][c] == 0) {
                div_map.innerHTML += '<div class="square"></div>';
            }
            if (map[r][c] == 9) {
                div_map.innerHTML += '<div class="square pacman"></div>'
            }

            if (map[r][c] == 3) {
                div_map.innerHTML += '<div class="square banan3"></div>'
            }

            if (map[r][c] == 6) {
                div_map.innerHTML += '<div class="square minion "></div>';
            }
            if (map[r][c] == 1) {
                div_map.innerHTML += '<div class="square banan1"></div>'
            }

            if (map[r][c] == 4) {
                div_map.innerHTML += '<div class="square bomb"></div>'
            }
            if (map[r][c] == 10) {
                div_map.innerHTML += '<div class="square pacman"> <div class="explosion"></div> </div>'
            }
            if (map[r][c] == 5) {
                div_map.innerHTML += '<div class="square Walls"></div>'
            }
        }
    }

}
showMap();
